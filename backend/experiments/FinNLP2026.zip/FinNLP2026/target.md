The 11th Workshop on Financial Technology and Natural Language Processing
EMNLP-2026, October 24th-29th, 2026, Budapest, Hungary

Workshop Description

The FinNLP workshop, as the annual event of ACL SIG-FinTech, focuses on applying NLP, Machine Learning, and Large Language Models to finance, economics, and law, aiming to drive interdisciplinary innovation and address unique challenges in these fields. Since 2019, FinNLP has served as a bridge between AI and NLP communities by collocating with major conferences. Its proceedings are available on the ACL Anthology.

FinNLP addresses the complexities of financial documents, which often contain tables and diverse multimodal data, as well as legal and compliance challenges in the financial industry. Key workshop topics include financial language modeling, multi-modal and graph representation learning, conversational agents, financial search and question answering, event discovery, compliance, and responsible AI practices in finance and law.

We have several interesting shared tasks in the collocated event, FinEval. Please refer to the FinEval page for more details.

Call for Paper

Topics of Interest
We invite submissions of original contributions on methods, theories, applications, and systems on artificial intelligence, machine learning, natural language processing & understanding, big data, statistical learning, data analytics, and deep learning, with a focus on knowledge discovery in the financial services domain. The scope of the workshop includes, but is not limited to, the following areas:

Language modeling on financial corpora, including tabular and numerical data, and multi-modal modeling
Graph representation learning and mining on financial data
Multi-source knowledge integration and fusion
Synthetic and genuine financial datasets and benchmarks
Transfer learning applications for financial data
Financial search and question answering systems
Event discovery and impact on organizational equity price
ESG event discovery, evaluation, and impact assessment
Compliance monitoring
Cross-disciplinary LLM-based methodologies for financial and legal domains
Applications of LLMs in financial auditing and regulatory reporting
Ethical implications and bias mitigation in AI applications
Hallucination mitigation and evaluation in LLMs
Privacy concerns and data protection strategies
Enhancing interpretability and explainability of LLM models
Responsible AI practices and governance
Methods, evaluation metrics, benchmarks, and datasets for LLMs in finance and law
Submission Details

Submission start: May 18, 2026, 7:00:00 AM
Submission Deadline: Aug 15, 2026, 7:00:00 AM
Submission System: https://openreview.net/group?id=EMNLP/2026/Workshop/FinNLP#tab-recent-activity
Paper Notification: TBD
Camera-Ready Deadline: TBD
FinNLP-2026@EMNLP: October 24th-29th, 2026
Location: Budapest, Hungary
Time zone: Anywhere On Earth (AOE)
Format
The ACL Template MUST be used for your submission(s). Accepted papers proceedings will be published at ACL Anthology.

Long Paper: May consist of up to 8 pages of content, plus unlimited pages for references and appendix.
Short Paper and Demo Paper: May consist of up to 4 pages of content, plus unlimited references and appendix.
Policies
The reviewing process will be double-blind for Long and Short Paper, and single-blind for Demo Paper. Submissions must be in electronic form using the paper submission link above.
At least one author of each accepted paper should register and present their work at FinNLP 2026.
As part of ACL SIG-FinTech's reproducibility and transparency initiative, we will pilot an open research policy for accepted papers.
Authors of accepted papers are strongly encouraged to publicly release their implementation code, model inputs, and model outputs to support reproducibility and future re-evaluation.
For LLM-based approaches, authors are encouraged to release prompts, inference configurations, generated outputs, and evaluation artifacts associated with their experiments whenever possible.
Exceptions may be granted in cases involving legal, licensing, privacy, commercial, or security constraints. Authors requesting exceptions should discuss their situation with the organizers.
Presentation videos from the workshop will be uploaded to the ACL SIG-FinTech YouTube channel for public access and long-term educational use.
Organizers

General Chairs
Chung-Chi Chen - National Institute of Informatics (NII), Japan
Yongjae Lee - UNIST, South Korea
Jimin Huang - The FinAI, US
Sophia Ananiadou - University of Manchester, UK
Hsin-Hsi Chen - National Taiwan University, Taiwan
Hiroya Takamura - AIST, Japan
Program Committee (Reviewer)
To Be Announced (TBA)



Regarding FinEval
Financial Information Access and Evaluation (FinEval)
Proposals are reviewed on a rolling basis

Shared tasks are collaborative initiatives where researchers and practitioners work together to address a common challenge using shared datasets and evaluation metrics. These tasks foster competition, collaboration, and advancement within the field, playing a significant role in both academic and industry communities. FinEval provides a venue for the community to share valuable insights and inspiration. Every year, we will call for proposals for the next edition of FinEval, which is collocated with the FinNLP workshop.

Call for Shared Task Proposal
We encourage submissions for tasks that test systems on financial text analysis, with a particular focus on cross-lingual, application-oriented tasks, and novel uses of NLP in finance. Tasks for non-English languages and cross-domain applications are welcome.

Proposal Criteria
Your task proposal will be evaluated on:

Novelty: Is the task addressing a unique or under-explored problem in financial NLP?
Interest: Will the task attract broad participation?
Data Quality: Is the data collection plan robust, with high inter-annotator agreement and appropriate licensing?
Evaluation: Is the evaluation methodology rigorous, and will it inspire future research?
Impact: What long-term impact will this task have on financial NLP?
Ethics: Data should avoid PII and adhere to ethical guidelines, including privacy compliance and ethical data use.
Task Organization
Organizers should be prepared to:

Ensure data quality and licensing, addressing ethical and security concerns.
Provide format checkers, baseline systems, and evaluation tools for participants.
Manage a competition platform (e.g., CodaLab) and maintain communication channels.
Write and present a task description paper at the FinEval session in FinNLP workshop.
Organize and review participant submissions and related documentation.
Organizer Roles
Lead Organizer: Oversees the task, ensuring timely completion of deliverables.
Co-Organizers: Assist with data preparation, evaluation, and participant communication.
Advisory Organizers: Provide guidance, not necessarily engaged in daily tasks.
Note: A minimum of two organizers is required per task. Single-organizer submissions will not be accepted.

Submission Guidelines
Task proposals should be in PDF format, following the ACL Template, and must be no longer than 4 pages (plus references). Include the following sections:

Overview: Summary, community interest, and anticipated impact.
Data & Resources: Data sources, copyright details, data quantity, quality assurance, and ethical considerations.
Pilot Task: (recommended) Results and insights from initial studies.
Evaluation: Clear evaluation methodology and criteria.
Task Reruns: If a rerun, provide justification and expected impact.
Task Organizers: Names, affiliations, contact details, and relevant experience.
Important Dates Submission
Please send the proposal to aclsigfintech@gmail.com

